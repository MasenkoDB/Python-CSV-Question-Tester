import csv
import random
import os
import platform

# Function to get the file path relative to the current directory
def get_relative_file_path(file_name):
    current_dir = os.getcwd()
    return os.path.join(current_dir, file_name)

class Test:
    def __init__(self, name):
        self.name = name
        self.questions = []
        self.randomize_questions = False

    def add_question(self, question):
        self.questions.append(question)

    def run_test(self):
        score = 0
        total_questions = len(self.questions)
        if self.randomize_questions:
            random.shuffle(self.questions)
        for question in self.questions:
            self.display_question(question)
            while True:
                user_choice = input("Your answer: ").upper()  # Convert user input to uppercase
                if user_choice.lower() == 'exit':  # Check if user wants to exit
                    return
                if len(question['answers']) > 2:
                    if user_choice in ['A', 'B', 'C', 'D']:  # Validate user input for multiple choice questions
                        break
                    else:
                        print("Invalid input! Please enter A, B, C, or D.")
                else:
                    if user_choice in ['A', 'B']:  # Validate user input for true/false questions
                        break
                    else:
                        print("Invalid input! Please enter A or B.")
            if user_choice == str(question['correct_answer']).upper():
                print("Correct!")
                score += 1
            else:
                print(f"Incorrect! The correct answer is: {question['correct_answer']}")
            input("Press Enter to continue...")
            clear_screen()  # Clear screen after each question
        print(f"Your score for the {self.name} test: {score}/{total_questions}")

    def display_question(self, question):
        print(f"\nTest: {self.name}")
        print(f"Question: {question['question']}")
        if len(question['answers']) > 2:  # Multiple choice question
            options = [ans for ans in question['answers'] if ans.strip()]  # Remove blank answers
            for i, ans in enumerate(options, start=65):  # Use ASCII characters starting from 'A'
                print(f"{chr(i)}. {ans}")
        else:  # True/false question
            print("A. True")
            print("B. False")
        print()

def clear_screen():
    if platform.system() == "Windows":
        os.system("cls")
    else:
        os.system("clear")

def main():
    # File path of the CSV file
    file_path = get_relative_file_path('Documents\Python\QuestionTester\questions.csv')

    tests = {}
    with open(file_path, newline='', encoding='utf-8') as csvfile:
        reader = csv.reader(csvfile)
        for row in reader:
            test_name, question, *answers, correct_answer = row
            if test_name not in tests:
                tests[test_name] = Test(test_name)
            tests[test_name].add_question({
                'question': question,
                'answers': answers,
                'correct_answer': correct_answer
            })

    while True:
        clear_screen()
        print("\n1. Take Individual Test")
        print("2. Take Randomized Test")
        print("3. Extras")
        print("4. Exit")
        choice = input("Enter your choice: ")
        clear_screen()  # Clear screen after the user inputs their choice

        if choice == '1':
            print("\nAvailable Tests:")
            for idx, test_name in enumerate(tests.keys(), start=1):
                print(f"{idx}. {test_name}")
            test_choice = int(input("Enter the test number: "))
            test_names = list(tests.keys())
            test = tests[test_names[test_choice-1]]
            clear_screen()  # Clear screen after the user selects a test
            test.run_test()
        elif choice == '2':
            all_questions = []
            for test in tests.values():
                all_questions.extend(test.questions)
            random.shuffle(all_questions)
            for question in all_questions:
                print(question['question'])
                if len(question['answers']) > 2:  # Multiple choice question
                    options = [ans for ans in question['answers'] if ans.strip()]  # Remove blank answers
                    for i, ans in enumerate(options, start=65):  # Use ASCII characters starting from 'A'
                        print(f"{chr(i)}. {ans}")
                else:  # True/false question
                    print("A. True")
                    print("B. False")
                while True:
                    user_choice = input("Your answer: ").upper()  # Convert user input to uppercase
                    if user_choice.lower() == 'exit':  # Check if user wants to exit
                        clear_screen()
                        break
                    if len(question['answers']) > 2:
                        if user_choice in ['A', 'B', 'C', 'D']:  # Validate user input for multiple choice questions
                            break
                        else:
                            print("Invalid input! Please enter A, B, C, or D.")
                    else:
                        if user_choice in ['A', 'B']:  # Validate user input for true/false questions
                            break
                        else:
                            print("Invalid input! Please enter A or B.")
                if user_choice.lower() == 'exit':  # Check if user wants to exit
                    break
                if user_choice == str(question['correct_answer']).upper():
                    print("Correct!")
                else:
                    print(f"Incorrect! The correct answer is: {question['correct_answer']}")
                input("Press Enter to continue...")
                clear_screen()  # Clear screen after each question
        elif choice == '3':
            while True:
                clear_screen()
                print("\nExtras Menu:")
                print(f"1. {'Clear screen after each question: Enabled' if platform.system() == 'Windows' else 'Clear screen after each question: Disabled'}")
                print(f"2. {'Randomize order of questions: Enabled' if any(test.randomize_questions for test in tests.values()) else 'Randomize order of questions: Disabled'}")
                print("3. Back to main menu")
                extra_choice = input("Enter your choice: ")
                if extra_choice == '1':
                    clear_screen()
                elif extra_choice == '2':
                    for test in tests.values():
                        test.randomize_questions = not test.randomize_questions
                elif extra_choice == '3':
                    break
                else:
                    print("Invalid choice!")
        elif choice == '4':
            print("Exiting program. Goodbye!")
            break
        else:
            print("Invalid choice!")

if __name__ == "__main__":
    main()
